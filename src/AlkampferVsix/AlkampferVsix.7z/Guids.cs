﻿// Guids.cs
// MUST match guids.h
using System;

namespace Company.AlkampferVsix
{
    static class GuidList
    {
        public const string guidAlkampferVsixPkgString = "160C1CF8-0317-4B97-9DAB-5512389D541A";
        public const string guidAlkampferVsixCmdSetString = "0EC1C4D9-2B0B-4DC8-8F8E-D057C5AEA138";

        public static readonly Guid guidAlkampferVsixCmdSet = new Guid(guidAlkampferVsixCmdSetString);
    }; 
}
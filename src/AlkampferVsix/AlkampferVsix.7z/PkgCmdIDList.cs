﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Company.AlkampferVsix
{
    class PkgCmdIDList
    {

        public const uint attachToIIS = 0x100;
        public const uint stopBuildAtFirstError = 0x101;
    }
}
